<?php
/**
 * Gerador de Contratos VOGA
 */

// ─── Planos VOGA ───────────────────────────────────────────────────────────
$voga_plans = [
    ['id'=>100,'network'=>'TIM','provider'=>'Voga 5Gb - Tim',  'price'=>34.99],
    ['id'=>101,'network'=>'TIM','provider'=>'Voga 8Gb - Tim',  'price'=>44.99],
    ['id'=>102,'network'=>'TIM','provider'=>'Voga 12Gb - Tim', 'price'=>49.99],
    ['id'=>103,'network'=>'TIM','provider'=>'Voga 22Gb - Tim', 'price'=>59.99],
    ['id'=>104,'network'=>'TIM','provider'=>'Voga 30Gb - Tim', 'price'=>69.99],
    ['id'=>105,'network'=>'TIM','provider'=>'Voga 40Gb - Tim', 'price'=>79.99],
    ['id'=>106,'network'=>'TIM','provider'=>'Voga 45Gb - Tim', 'price'=>89.99],
    ['id'=>700,'network'=>'VIVO','provider'=>'Voga 1 GB - VIVO',        'price'=>24.99],
    ['id'=>701,'network'=>'VIVO','provider'=>'Voga 3 GB + 2GB - VIVO',  'price'=>39.99],
    ['id'=>702,'network'=>'VIVO','provider'=>'Voga 5 GB + 3GB - VIVO',  'price'=>49.99],
    ['id'=>703,'network'=>'VIVO','provider'=>'Voga 10 GB + 5GB - VIVO', 'price'=>59.99],
    ['id'=>704,'network'=>'VIVO','provider'=>'Voga 15 GB + 5GB - VIVO', 'price'=>64.99],
    ['id'=>705,'network'=>'VIVO','provider'=>'Voga 25 GB + 5GB - VIVO', 'price'=>89.99],
];

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function find_plan($plans,$id){ foreach($plans as $p) if((int)$p['id']===(int)$id) return $p; return null; }

// ─── Extração do TXT ───────────────────────────────────────────────────────
$extracted_data = null;
if (isset($_FILES['invoice_txt']) && $_FILES['invoice_txt']['error'] == 0) {
    $content = file_get_contents($_FILES['invoice_txt']['tmp_name']);
    $content = str_replace(["\r\n","\r"], "\n", $content);
    $lines_raw = explode("\n", $content);

    $client_name=''; $client_cnpj=''; $client_address='';
    $client_neighborhood=''; $client_city=''; $client_state='';
    $client_cep=''; $client_phone=''; $client_email='';
    $extracted_lines=[];

    foreach ($lines_raw as $line) {
        $line = trim($line);
        if (!$line) continue;
        if (!$client_cnpj && preg_match('/(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})/', $line, $m)) $client_cnpj=$m[1];
        if (!$client_cep  && preg_match('/(\d{5}-\d{3})/', $line, $m)) $client_cep=$m[1];
        if (!$client_phone && preg_match('/\(\d{2}\)\s*[\d]{4,5}-\d{4}/', $line, $m)) $client_phone=$m[0];
        if (!$client_email && preg_match('/[\w.\-]+@[\w.\-]+\.\w{2,}/', $line, $m)) $client_email=$m[0];
        if (!$client_state && preg_match('/\b([A-Z]{2})\b/', $line, $m) && in_array($m[1],['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'])) $client_state=$m[1];
        if (preg_match_all('/(?:\(?\d{2}\)?[\s\-])(\d{4,5})[\s\-](\d{4})/', $line, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $mm) {
                // extrai DDD da linha
                preg_match('/\(?(\d{2})\)?[\s\-]/', $line, $ddd);
                if (!$ddd) continue;
                $num = $ddd[1].'-'.$mm[1].'-'.$mm[2];
                if (strlen(preg_replace('/\D/','',$num)) < 10) continue;
                $exists=false; foreach($extracted_lines as $el) if($el['number']==$num) $exists=true;
                if (!$exists) $extracted_lines[]=['number'=>$num,'cancelled'=>false];
            }
        }
    }
    // Razão Social: linha toda em maiúsculas com indicativo jurídico
    foreach ($lines_raw as $line) {
        $line=trim($line);
        if (!$client_name && mb_strlen($line)>5 && mb_strtoupper($line)===$line && preg_match('/\b(LTDA|S\.A\.|ME|EIRELI|EPP|SS|SLU)\b/i',$line))
            $client_name=$line;
    }
    // Endereço
    foreach ($lines_raw as $line) {
        $line=trim($line);
        if (!$client_address && preg_match('/\b(RUA|AV\.?|AVENIDA|AL\.?|ESTRADA|RODOVIA|ROD\.?|TRAVESSA|PRACA|PRAÇA)\b/i',$line))
            $client_address=$line;
    }
    $extracted_data=[
        'clientName'=>$client_name,'clientCNPJ'=>$client_cnpj,
        'clientAddress'=>$client_address,'clientNeighborhood'=>$client_neighborhood,
        'clientCity'=>$client_city,'clientState'=>$client_state,
        'clientCEP'=>$client_cep,'clientPhone'=>$client_phone,'clientEmail'=>$client_email,
        'lines'=>$extracted_lines,
    ];
}

// Modo manual sem TXT
if (isset($_POST['manual_mode'])) {
    $extracted_data=['clientName'=>'','clientCNPJ'=>'','clientAddress'=>'','clientNeighborhood'=>'','clientCity'=>'','clientState'=>'','clientCEP'=>'','clientPhone'=>'','clientEmail'=>'','lines'=>[]];
}

// ─── Modo Impressão ────────────────────────────────────────────────────────
if (isset($_POST['print_mode'])) {
    $cd        = json_decode($_POST['client_data'], true);
    $sp        = $_POST['selected_plans']  ?? [];
    $cancelled = $_POST['cancelled_lines'] ?? [];
    $new_lines = json_decode($_POST['new_lines'] ?? '[]', true);
    $operator  = $_POST['operator']        ?? 'TIM';
    $fidelity  = $_POST['fidelity']        ?? 'none';
    $obs       = trim($_POST['observations'] ?? '');

    $operator_full = $operator==='TIM' ? 'TIM (SURF)' : 'VIVO (TELECALL)';
    $fidelity_text = $fidelity==='none' ? 'Sem Fidelidade' : "$fidelity meses";

    $all_lines=[];
    foreach ($cd['lines'] as $idx=>$line) {
        if (isset($cancelled[$idx])) continue;
        $plan = find_plan($voga_plans, $sp[$idx] ?? 0);
        $all_lines[]=['number'=>$line['number'],'plan'=>$plan];
    }
    foreach ($new_lines as $nl) {
        $plan=find_plan($voga_plans,$nl['plan_id']);
        $all_lines[]=['number'=>$nl['number'],'plan'=>$plan,'new'=>true];
    }

    $total=0; $idx_count=1; $lines_rows='';
    foreach ($all_lines as $al) {
        $price=$al['plan']?$al['plan']['price']:0; $total+=$price;
        $pname=$al['plan']?esc($al['plan']['provider']):'---';
        $num=esc($al['number']);
        $tipo=isset($al['new'])?' <span style="color:#aaa;font-size:8px">(Nova)</span>':'';
        $lines_rows.="<tr>
            <td style='padding:5px 10px;border:1px solid #e5c7c7;text-align:center'>$idx_count</td>
            <td style='padding:5px 10px;border:1px solid #e5c7c7'>$num$tipo</td>
            <td style='padding:5px 10px;border:1px solid #e5c7c7'>$pname</td>
            <td style='padding:5px 10px;border:1px solid #e5c7c7;text-align:right'>R$&nbsp;".number_format($price,2,',','.')."</td>
        </tr>";
        $idx_count++;
    }
    $qty_lines=count($all_lines);
    $total_fmt='R$ '.number_format($total,2,',','.');
    $today=date('d/m/Y');
    $client_name_esc=esc($cd['clientName']);

    if ($operator==='TIM') {
        $op_nome='SURF TELECOM'; $op_cnpj='10.455.746/0004-96';
        $op_end='Av. Magalhães de Castro, 4800, Conj 161 – Cidade Jardim – São Paulo/SP – CEP 05.676-120';
        $op_fone='(11) 3755-0155';
    } else {
        $op_nome='TELECALL'; $op_cnpj='07.625.852/0001-13';
        $op_end='Avenida das Américas, 4.485, Loja 112 e 113 – Barra da Tijuca – Rio de Janeiro/RJ – CEP 22.640-102';
        $op_fone='(21) 3030-1010';
    }
    $fid_clause = $fidelity!=='none'
        ? "9.1. Fidelidade de <strong>$fidelity meses</strong> conforme este Termo de Adesão. Em caso de cancelamento antecipado sem justa causa, aplica-se multa rescisória de 30% sobre o valor das parcelas vincendas (Multa = 30% × parcelas restantes)."
        : "9.1. Contrato <strong>sem fidelidade</strong>. Cancelamento a qualquer momento sem multa rescisória.";

    header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Contrato Voga – <?php echo $client_name_esc; ?></title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Montserrat',sans-serif;font-size:10px;color:#2d2d2d;background:#fff;line-height:1.6}
.no-print{position:fixed;top:18px;right:18px;z-index:999}
.no-print button{background:#E31E24;color:#fff;border:none;padding:12px 28px;border-radius:8px;font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 4px 14px rgba(227,30,36,.4)}
.no-print button:hover{background:#c0141a}
.page{width:210mm;min-height:297mm;padding:18mm 22mm 24mm;position:relative;page-break-after:always;background:#fff}
@media screen{.page{margin:0 auto 40px;box-shadow:0 2px 18px rgba(0,0,0,.12);border-radius:4px}}
.page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding-bottom:8px;border-bottom:2.5px solid #E31E24}
.logo-text{font-size:28px;font-weight:700;color:#E31E24;font-style:italic;letter-spacing:-1px}
.page-label{font-size:9px;color:#aaa;font-weight:600;letter-spacing:.5px}
h1.doc-title{text-align:center;color:#2d2d2d;font-size:12px;text-transform:uppercase;letter-spacing:.5px;margin:10px 0 14px;font-weight:700}
h2.section-title{color:#E31E24;font-size:10px;text-transform:uppercase;letter-spacing:.4px;margin:13px 0 5px;font-weight:700}
.dados-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;margin-bottom:10px}
.dado-item{font-size:9.5px}.dado-item .label{color:#E31E24;font-weight:700;text-transform:uppercase;font-size:8px;display:block}.dado-item .valor{color:#2d2d2d}
.dado-full{grid-column:1/-1}
table.linhas{width:100%;border-collapse:collapse;margin:8px 0;font-size:9.5px}
table.linhas thead tr{background:#fdf2f2}
table.linhas th{padding:6px 10px;border:1px solid #e5c7c7;color:#E31E24;font-weight:700;font-size:8.5px;text-transform:uppercase}
table.linhas td{padding:5px 10px;border:1px solid #e5c7c7;vertical-align:middle}
.total-row{text-align:right;font-size:11px;font-weight:700;color:#E31E24;margin:7px 0 4px}
.info-box{background:#fdf2f2;border-left:4px solid #E31E24;padding:8px 12px;margin:8px 0;font-size:9.5px;border-radius:0 4px 4px 0}
p.c{font-size:9.3px;margin-bottom:4px;text-align:justify}p.c strong{color:#E31E24}
table.sla{width:100%;border-collapse:collapse;margin:6px 0;font-size:9px}
table.sla th{background:#fdf2f2;border:1px solid #e5c7c7;padding:5px 8px;color:#E31E24;font-weight:700;text-align:center}
table.sla td{border:1px solid #e5c7c7;padding:5px 8px;text-align:center}
.assinatura{display:flex;justify-content:space-between;margin-top:26px;gap:20px}
.sig-block{flex:1;text-align:center}
.sig-line{border-top:1px solid #2d2d2d;padding-top:4px;font-size:8.5px;color:#555}
.sig-label{font-size:8px;color:#888;margin-top:2px}
.page-footer{position:absolute;bottom:12mm;left:22mm;right:22mm;display:flex;align-items:center;justify-content:space-between;border-top:1px solid #eee;padding-top:5px}
.page-footer span{font-size:8px;color:#bbb}
@media print{.no-print{display:none}body{background:#fff}@page{size:A4;margin:0}.page{margin:0;box-shadow:none;border-radius:0}}
</style>
</head>
<body>
<div class="no-print"><button onclick="window.print()">⬇ Imprimir / Salvar PDF</button></div>

<!-- PÁGINA 1 – TERMO DE ADESÃO -->
<div class="page">
  <div class="page-header"><span class="logo-text">Voga</span><span class="page-label">Proposta Comercial e Termo de Adesão</span></div>
  <h1 class="doc-title">Proposta Comercial e Termo de Adesão – Voga</h1>
  <h2 class="section-title">Dados da Empresa</h2>
  <div class="dados-grid">
    <div class="dado-item dado-full"><span class="label">Nome Empresarial</span><span class="valor"><?php echo esc($cd['clientName'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">CNPJ</span><span class="valor"><?php echo esc($cd['clientCNPJ'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">Operadora</span><span class="valor"><?php echo esc($operator_full); ?></span></div>
    <div class="dado-item dado-full"><span class="label">Endereço</span><span class="valor"><?php echo esc($cd['clientAddress'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">Bairro</span><span class="valor"><?php echo esc($cd['clientNeighborhood'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">Cidade / Estado</span><span class="valor"><?php echo esc($cd['clientCity'])?:'—'; ?> / <?php echo esc($cd['clientState'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">CEP</span><span class="valor"><?php echo esc($cd['clientCEP'])?:'—'; ?></span></div>
    <div class="dado-item"><span class="label">Telefone</span><span class="valor"><?php echo esc($cd['clientPhone'])?:'—'; ?></span></div>
    <div class="dado-item dado-full"><span class="label">E-mail</span><span class="valor"><?php echo esc($cd['clientEmail'])?:'—'; ?></span></div>
  </div>
  <h2 class="section-title">Linhas para Portabilidades</h2>
  <p class="c"><strong>Quantidade:</strong> <?php echo $qty_lines; ?> linha(s)</p>
  <h2 class="section-title">Linhas e Planos</h2>
  <table class="linhas">
    <thead><tr><th>#</th><th>Número</th><th>Plano Voga</th><th style="text-align:right">Valor</th></tr></thead>
    <tbody><?php echo $lines_rows; ?></tbody>
  </table>
  <div class="total-row">Valor Total do Contrato: <?php echo $total_fmt; ?></div>
  <div class="dados-grid" style="margin-top:10px">
    <div class="dado-item"><span class="label">Fidelidade</span><span class="valor"><?php echo esc($fidelity_text); ?></span></div>
    <?php if($obs): ?><div class="dado-item dado-full"><span class="label">Observações</span><span class="valor"><?php echo nl2br(esc($obs)); ?></span></div><?php endif; ?>
  </div>
  <div class="assinatura">
    <div class="sig-block"><div class="sig-line">Voga Inovações Tecnológica LTDA</div><div class="sig-label">CONTRATANTE</div></div>
    <div class="sig-block"><div class="sig-line"><?php echo $client_name_esc; ?></div><div class="sig-label">CLIENTE</div></div>
  </div>
  <div class="page-footer"><span>Voga Inovações Tecnológica LTDA</span><span>2</span><span><?php echo $today; ?></span></div>
</div>

<!-- PÁGINA 2 – CONTRATO CLÁUSULAS 1–6 -->
<div class="page">
  <div class="page-header"><span class="logo-text">Voga</span><span class="page-label">Contrato de Prestação de Serviços de Telefonia Móvel</span></div>
  <h1 class="doc-title">Contrato de Prestação de Serviços de Telefonia Móvel – Voga</h1>
  <p class="c"><strong>CONTRATANTE:</strong> Voga Inovações Tecnológica LTDA</p>
  <p class="c"><strong>CLIENTE:</strong> <?php echo $client_name_esc; ?></p>
  <p class="c" style="margin-top:6px">Este contrato explica como funcionam os serviços da <strong>Voga</strong> e estabelece seus direitos e deveres como <strong>CLIENTE</strong>. Nosso compromisso é ser claro, transparente e eficiente.</p>

  <h2 class="section-title">1. Objeto</h2>
  <p class="c">1.1. Este contrato trata da prestação de serviços de telefonia móvel (SMP), que podem incluir: Ligações (voz); Internet móvel (dados); Mensagens de texto (SMS); tudo conforme o plano escolhido no Termo de Adesão.</p>
  <p class="c">1.2. A <strong>Voga</strong> atua como gestora comercial e integradora do serviço, utilizando infraestrutura de operadoras autorizadas pela ANATEL (TIM via SURF Telecom ou VIVO via TELECALL), conforme definido no Termo de Adesão.</p>
  <p class="c">1.3. Atendimento, suporte, faturamento e cobrança são realizados diretamente pela <strong>Voga</strong>, sendo esta a única interlocutora do <strong>CLIENTE</strong>.</p>

  <h2 class="section-title">2. Início, Duração e Ativação</h2>
  <p class="c">2.1. O serviço inicia após: (a) Assinatura do Termo de Adesão (físico ou aceite eletrônico); e (b) Ativação da linha. 2.2. O contrato é por prazo indeterminado. 2.3. O <strong>CLIENTE</strong> poderá gerenciar seus serviços via aplicativo ou portal digital da <strong>Voga</strong>, incluindo alteração de plano, pacotes adicionais e consulta de consumo. 2.4. A ativação poderá ocorrer de forma 100% digital mediante QR Code, cadastro online, documentos e validação biométrica. 2.5. O <strong>CLIENTE</strong> pode solicitar cancelamento a qualquer momento, conforme Cláusula 16. 2.6. Caso haja benefícios com condição de permanência, poderá ser aplicada multa proporcional, conforme Cláusula 9.</p>

  <h2 class="section-title">3. Seus Direitos (Base ANATEL + LGPD)</h2>
  <p class="c">O <strong>CLIENTE</strong> possui todos os direitos previstos na regulamentação da ANATEL (RGC – Resolução nº 632/2014 e atualizações) e na LGPD (Lei nº 13.709/2018), incluindo: receber o serviço com qualidade técnica; acesso claro e prévio a valores e condições; não ser cobrado por serviços não contratados; solicitar portabilidade numérica sem custo; receber atendimento com protocolo; ter seus dados tratados com segurança e transparência; registrar reclamações junto à Voga, ANATEL ou PROCON.</p>

  <h2 class="section-title">4. Dependência da Rede da Operadora Parceira</h2>
  <p class="c">4.1. A infraestrutura de rede pertence e é operada exclusivamente pelas operadoras parceiras (TIM ou VIVO). 4.2. A <strong>Voga</strong> não se responsabiliza por: falhas de cobertura, oscilação de sinal ou indisponibilidade técnica; interrupções por manutenção, casos fortuitos ou força maior; limitações geográficas ou tecnológicas inerentes à tecnologia móvel. 4.3. Não há garantia de disponibilidade ininterrupta, ressalvados os padrões mínimos da ANATEL.</p>

  <h2 class="section-title">5. Suporte e Atendimento</h2>
  <p class="c">5.1. Toda solicitação deve ser direcionada exclusivamente à <strong>Voga</strong> pelos canais oficiais. 5.2. Nível 1 e 2: atendimento pela equipe Voga. Nível 3: escalonamento à operadora parceira quando a falha for de infraestrutura. 5.3. A <strong>Voga</strong> acompanhará integralmente a tratativa, mantendo o <strong>CLIENTE</strong> informado.</p>

  <h2 class="section-title">6. SLA – Nível de Serviço e Prazos</h2>
  <p class="c">6.1. Os prazos de atendimento observam as diretrizes da ANATEL e acordos com as operadoras. 6.2. A contagem inicia na abertura do chamado com geração de protocolo.</p>
  <table class="sla">
    <thead><tr><th>Severidade</th><th>Definição</th><th>Tempo de Resposta</th><th>Prazo de Solução (Meta)</th></tr></thead>
    <tbody>
      <tr><td><strong>Alta</strong></td><td>Indisponibilidade total (voz/dados/SMS)</td><td>Até 1 hora</td><td>Até 9 horas (90% dos casos)</td></tr>
      <tr><td><strong>Média</strong></td><td>Degradação parcial ou intermitência</td><td>Até 4 horas</td><td>Até 36 horas (90% dos casos)</td></tr>
      <tr><td><strong>Baixa</strong></td><td>Impacto leve / solicitações administrativas</td><td>Até 48 horas</td><td>Até 120 horas (90% dos casos)</td></tr>
    </tbody>
  </table>
  <p class="c">6.4. Prazos de Nível 3 dependem da operadora parceira, sendo a <strong>Voga</strong> responsável pela intermediação. 6.5. Eventos externos (manutenção, energia, clima) podem impactar prazos, não caracterizando descumprimento.</p>

  <div class="page-footer"><span>Voga Inovações Tecnológica LTDA</span><span>3</span><span><?php echo $today; ?></span></div>
</div>

<!-- PÁGINA 3 – CLÁUSULAS 7–16 -->
<div class="page">
  <div class="page-header"><span class="logo-text">Voga</span><span class="page-label">Contrato – continuação</span></div>

  <h2 class="section-title">7. Planos, Linhas e Valores</h2>
  <p class="c">Todos os detalhes sobre operadora, quantidade de linhas, planos, franquias e valores estão especificados no Termo de Adesão, que integra este contrato.</p>

  <h2 class="section-title">8. Cobrança e Pagamento</h2>
  <p class="c">8.1. Modelo pós-pago, faturamento mensal, boleto/Pix. 8.2. Em caso de atraso: multa moratória de 2%; juros de 1% ao mês pro rata die; atualização pelo IPCA/IGP-M. 8.3. Penalidades por inadimplência: 15 dias – suspensão parcial; 30 dias – suspensão total; 60 dias – cancelamento automático e possível inscrição em órgãos de proteção ao crédito. 8.4. Reativação condicionada à quitação dos débitos.</p>

  <h2 class="section-title">9. Fidelidade e Multa Rescisória</h2>
  <p class="c"><?php echo $fid_clause; ?></p>
  <p class="c">9.3. O percentual de 30% incide sempre sobre o saldo remanescente, nunca sobre o valor total original. 9.4. A multa NÃO se aplica em caso de: cancelamento por falha comprovada e não sanada; mudança de endereço para local sem cobertura da operadora (mediante comprovação). 9.5. Toda solicitação de cancelamento será analisada individualmente.</p>

  <h2 class="section-title">10. Uso Adequado e Suspensão por Risco</h2>
  <p class="c">10.1. É vedado usar o serviço para: gateway GSM não autorizado; disparos massivos (SMS/voz) para spam ou fraudes; práticas ilegais; equipamentos não homologados pela ANATEL. 10.2. A <strong>Voga</strong> pode suspender imediatamente em caso de suspeita de fraude, uso indevido ou determinação judicial. 10.3. O <strong>CLIENTE</strong> será notificado e terá 48h para regularizar, sob pena de cancelamento definitivo.</p>

  <h2 class="section-title">11. Responsabilidades do Cliente</h2>
  <p class="c">O <strong>CLIENTE</strong> é responsável por: uso adequado das linhas, inclusive por funcionários e prepostos; guarda e sigilo dos chips (SIM e eSIM); comunicação imediata à <strong>Voga</strong> em caso de perda ou roubo. Todos os custos anteriores à comunicação formal são de responsabilidade do <strong>CLIENTE</strong>.</p>

  <h2 class="section-title">12. Alteração de Planos e Condições</h2>
  <p class="c">12.1. Planos sem fidelidade: a <strong>Voga</strong> pode alterar condições com aviso de 30 dias. 12.2. Planos com fidelidade: condições mantidas durante o prazo de permanência, salvo acordo expresso. 12.3. Alterações regulatórias ou técnicas comunicadas previamente, com direito de cancelamento sem multa.</p>

  <h2 class="section-title">13. Limitação de Responsabilidade</h2>
  <p class="c">13.1. A responsabilidade total da <strong>Voga</strong> fica limitada ao valor pago pelo <strong>CLIENTE</strong> nos últimos 3 meses. 13.2. A <strong>Voga</strong> não se responsabiliza por lucros cessantes, perda de oportunidade, danos indiretos, uso indevido ou falhas de equipamentos do <strong>CLIENTE</strong>.</p>

  <h2 class="section-title">14. Direito de Regresso e Suporte Jurídico</h2>
  <p class="c">14.1. Em caso de falhas atribuíveis à operadora parceira, a <strong>Voga</strong> atuará na defesa dos interesses do <strong>CLIENTE</strong>, buscando ressarcimento e fornecendo documentação necessária (protocolos, evidências, relatórios). 14.2. A <strong>Voga</strong> auxiliará o <strong>CLIENTE</strong> em eventuais demandas extrajudiciais ou judiciais dentro de suas possibilidades operacionais.</p>

  <h2 class="section-title">15. Proteção de Dados (LGPD)</h2>
  <p class="c">15.1. Os dados do <strong>CLIENTE</strong> são tratados para: execução contratual; faturamento e suporte; obrigações legais (ANATEL, Receita Federal); melhoria e comunicação comercial (com opção de descadastramento a qualquer momento). 15.2. O <strong>CLIENTE</strong> pode exercer direitos LGPD (acesso, correção, exclusão, portabilidade) pelos canais oficiais da <strong>Voga</strong>. 15.3. Operadoras parceiras são contratualmente obrigadas a tratar dados apenas para finalidades específicas de processamento de rede.</p>

  <h2 class="section-title">16. Cancelamento</h2>
  <p class="c">16.1. O <strong>CLIENTE</strong> pode solicitar cancelamento a qualquer momento pelos canais oficiais. 16.2. Procedimento: solicitação formal com identificação; quitação de débitos pendentes; devolução de equipamentos (se aplicável). 16.3. Multa rescisória aplicável somente se houver fidelidade ativa, conforme Cláusula 9. 16.4. Efetivado imediatamente ou em até 2 dias úteis, com cobrança proporcional aos dias utilizados.</p>

  <div class="page-footer"><span>Voga Inovações Tecnológica LTDA</span><span>4</span><span><?php echo $today; ?></span></div>
</div>

<!-- PÁGINA 4 – DISPOSIÇÕES GERAIS + DADOS OPERADORA + ASSINATURA -->
<div class="page">
  <div class="page-header"><span class="logo-text">Voga</span><span class="page-label">Disposições Gerais e Dados da Operadora</span></div>

  <h2 class="section-title">17. Serviços Adicionais</h2>
  <p class="c">A <strong>Voga</strong> poderá oferecer serviços complementares como: gestão de consumo e relatórios analíticos; otimização de custos e consultoria; suporte técnico avançado; integração com sistemas do <strong>CLIENTE</strong>. Tais serviços serão objeto de proposta comercial específica e integrados ao Termo de Adesão.</p>

  <h2 class="section-title">18. Disposições Gerais</h2>
  <p class="c">18.1. Este contrato rege-se pelas normas da ANATEL, Código de Defesa do Consumidor e legislação brasileira aplicável. 18.2. A <strong>Voga</strong> pode atualizar este contrato para adequação regulatória com aviso de 30 dias. O <strong>CLIENTE</strong> pode cancelar sem multa se discordar das alterações. 18.3. Foro eleito: comarca da sede da <strong>Voga</strong>, com renúncia a qualquer outro. 18.4. Tolerância em caso de descumprimento não implica novação ou renúncia de direitos.</p>

  <h2 class="section-title">Dados da Empresa Prestadora de Origem</h2>
  <div class="info-box">
    <p style="margin-bottom:4px"><strong>Nome Empresarial:</strong> <?php echo esc($op_nome); ?> &nbsp;|&nbsp; <strong>CNPJ:</strong> <?php echo esc($op_cnpj); ?></p>
    <p style="margin-bottom:4px"><strong>Endereço:</strong> <?php echo esc($op_end); ?></p>
    <p><strong>Telefone / SAC:</strong> <?php echo esc($op_fone); ?></p>
  </div>

  <!-- Anexo I resumido -->
  <h2 class="section-title">Anexo I – SLA Detalhado</h2>
  <p class="c"><strong>Atendimento SEMPRE prestado pela Voga.</strong> Contagem inicia na abertura do chamado. Limitações: dependência da rede da operadora; eventos externos (energia, cobertura, terceiros); manutenções programadas.</p>
  <p class="c">O <strong>CLIENTE</strong> declara ter lido, compreendido e concordado com todas as cláusulas deste contrato e do Termo de Adesão, assinando-os em <?php echo $today; ?>.</p>

  <div class="assinatura" style="margin-top:30px">
    <div class="sig-block"><div class="sig-line">Voga Inovações Tecnológica LTDA</div><div class="sig-label">CONTRATANTE – <?php echo $today; ?></div></div>
    <div class="sig-block"><div class="sig-line"><?php echo $client_name_esc; ?></div><div class="sig-label">CLIENTE – <?php echo $today; ?></div></div>
  </div>

  <div class="page-footer"><span>Voga Inovações Tecnológica LTDA</span><span>5</span><span><?php echo $today; ?></span></div>
</div>

</body></html>
<?php exit; }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VOGA – Gerador de Contratos</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style>body{font-family:'Montserrat',sans-serif}</style>
</head>
<body class="bg-slate-50 min-h-screen">

<header class="bg-white shadow-sm border-b border-slate-200">
  <div class="max-w-5xl mx-auto px-4 py-4 flex items-center gap-3">
    <span class="text-3xl font-bold italic text-red-600">Voga</span>
    <span class="text-slate-400 text-sm font-semibold">Gerador de Contratos</span>
  </div>
</header>

<div class="max-w-5xl mx-auto py-10 px-4 space-y-6">

<?php if (!$extracted_data): ?>
<!-- Passo 1: Upload -->
<div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-10">
  <h1 class="text-2xl font-bold text-slate-900 mb-1">Importar Arquivo TXT</h1>
  <p class="text-slate-500 text-sm mb-8">Selecione o arquivo TXT exportado pela operadora para preencher os dados automaticamente.</p>
  <form action="" method="post" enctype="multipart/form-data">
    <label for="invoice_txt" class="cursor-pointer block">
      <div class="border-2 border-dashed border-slate-300 rounded-xl p-14 text-center hover:border-red-500 transition-colors group">
        <svg class="w-14 h-14 text-slate-300 group-hover:text-red-400 mx-auto mb-4 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
        </svg>
        <p class="text-lg font-semibold text-slate-700 group-hover:text-red-600 transition-colors">Clique para selecionar o arquivo TXT</p>
        <p class="text-sm text-slate-400 mt-1">O preenchimento será automático após a seleção</p>
      </div>
      <input type="file" name="invoice_txt" id="invoice_txt" class="hidden" accept=".txt" onchange="this.form.submit()">
    </label>
  </form>
  <div class="mt-8 pt-6 border-t border-slate-100">
    <form action="" method="post">
      <input type="hidden" name="manual_mode" value="1">
      <button type="submit" class="text-sm font-semibold text-red-600 hover:underline">→ Preencher dados manualmente (sem importar TXT)</button>
    </form>
  </div>
</div>

<?php elseif ($extracted_data): ?>
<!-- Passo 2: Formulário -->
<form action="" method="post" target="_blank" id="main-form">
  <input type="hidden" name="print_mode" value="1">
  <input type="hidden" name="client_data" id="client_data_field" value='<?php echo esc(json_encode($extracted_data)); ?>'>
  <input type="hidden" name="new_lines" id="new_lines_field" value="[]">

  <!-- Dados da empresa -->
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
    <?php if(!empty($extracted_data['clientName'])): ?>
    <div class="flex items-center gap-2 mb-5">
      <svg class="w-5 h-5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      <h2 class="text-lg font-bold text-slate-900">Dados Importados – verifique e edite se necessário</h2>
    </div>
    <?php else: ?>
    <h2 class="text-lg font-bold text-slate-900 mb-5">Dados da Empresa</h2>
    <?php endif; ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div class="md:col-span-2">
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Nome Empresarial / Razão Social *</label>
        <input type="text" id="f_name" value="<?php echo esc($extracted_data['clientName']); ?>" required class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 focus:border-red-400 outline-none" placeholder="Ex: EMPRESA EXEMPLO LTDA">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">CNPJ</label>
        <input type="text" id="f_cnpj" value="<?php echo esc($extracted_data['clientCNPJ']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="00.000.000/0000-00">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Telefone</label>
        <input type="text" id="f_phone" value="<?php echo esc($extracted_data['clientPhone']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="(00) 00000-0000">
      </div>
      <div class="md:col-span-2">
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">E-mail</label>
        <input type="email" id="f_email" value="<?php echo esc($extracted_data['clientEmail']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="contato@empresa.com.br">
      </div>
      <div class="md:col-span-2">
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Endereço</label>
        <input type="text" id="f_address" value="<?php echo esc($extracted_data['clientAddress']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="Rua / Avenida, nº">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Bairro</label>
        <input type="text" id="f_neighborhood" value="<?php echo esc($extracted_data['clientNeighborhood']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Cidade</label>
        <input type="text" id="f_city" value="<?php echo esc($extracted_data['clientCity']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Estado (UF)</label>
        <input type="text" id="f_state" value="<?php echo esc($extracted_data['clientState']); ?>" maxlength="2" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none uppercase" placeholder="SP">
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">CEP</label>
        <input type="text" id="f_cep" value="<?php echo esc($extracted_data['clientCEP']); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="00000-000">
      </div>
    </div>
  </div>

  <!-- Condições Comerciais -->
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
    <h2 class="text-lg font-bold text-slate-900 mb-4">Condições Comerciais</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Operadora</label>
        <select name="operator" id="operator_select" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" onchange="filterPlans()">
          <option value="TIM">TIM (SURF)</option>
          <option value="VIVO">VIVO (TELECALL)</option>
        </select>
      </div>
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Fidelidade</label>
        <select name="fidelity" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none">
          <option value="none">Sem Fidelidade</option>
          <option value="12">12 Meses</option>
          <option value="24">24 Meses</option>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Observações</label>
        <textarea name="observations" rows="2" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 outline-none" placeholder="Condições adicionais, se houver..."></textarea>
      </div>
    </div>
  </div>

  <!-- Linhas -->
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
    <div class="flex items-center justify-between mb-4">
      <h2 class="text-lg font-bold text-slate-900">Linhas e Planos <span id="lines_count" class="text-sm text-slate-400 font-normal"></span></h2>
    </div>

    <?php if (!empty($extracted_data['lines'])): ?>
    <div class="overflow-x-auto mb-4 rounded-lg border border-slate-100">
      <table class="w-full text-sm">
        <thead class="bg-slate-50">
          <tr>
            <th class="text-left py-2.5 px-3 text-xs font-semibold text-slate-500 uppercase">Número</th>
            <th class="text-left py-2.5 px-3 text-xs font-semibold text-slate-500 uppercase">Plano Voga</th>
            <th class="text-right py-2.5 px-3 text-xs font-semibold text-slate-500 uppercase">Valor</th>
            <th class="py-2.5 px-3 text-xs font-semibold text-slate-500 uppercase text-center">Ação</th>
          </tr>
        </thead>
        <tbody id="lines_table" class="divide-y divide-slate-100">
          <?php foreach ($extracted_data['lines'] as $idx => $line): ?>
          <tr id="row_<?php echo $idx; ?>">
            <td class="py-2 px-3 font-medium text-slate-800"><?php echo esc($line['number']); ?></td>
            <td class="py-2 px-3">
              <select name="selected_plans[<?php echo $idx; ?>]" class="plan-select w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs focus:ring-2 focus:ring-red-400 outline-none" onchange="updateTotal()">
                <?php foreach($voga_plans as $p): ?>
                <option value="<?php echo $p['id']; ?>" data-network="<?php echo $p['network']; ?>" data-price="<?php echo $p['price']; ?>">
                  <?php echo esc($p['provider']); ?> – R$ <?php echo number_format($p['price'],2,',','.'); ?>
                </option>
                <?php endforeach; ?>
              </select>
            </td>
            <td class="py-2 px-3 text-right font-semibold text-red-600 text-xs" id="price_<?php echo $idx; ?>">—</td>
            <td class="py-2 px-3 text-center">
              <button type="button" onclick="cancelLine(<?php echo $idx; ?>)" id="cancel_btn_<?php echo $idx; ?>" class="text-xs text-red-500 hover:text-red-700 font-semibold border border-red-200 rounded px-2 py-1 hover:bg-red-50 transition-colors">Cancelar linha</button>
              <input type="hidden" name="cancelled_lines[<?php echo $idx; ?>]" id="cancel_input_<?php echo $idx; ?>" disabled>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <p class="text-sm text-slate-400 mb-4 italic">Nenhuma linha importada do TXT. Adicione linhas abaixo.</p>
    <?php endif; ?>

    <div id="new_lines_container" class="space-y-2 mb-4"></div>

    <button type="button" onclick="addNewLine()" class="flex items-center gap-2 text-sm font-semibold text-red-600 border border-red-200 rounded-lg px-4 py-2 hover:bg-red-50 transition-colors">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      Adicionar Nova Linha (sem portabilidade)
    </button>

    <div class="mt-5 pt-4 border-t border-slate-200 flex justify-end">
      <div class="text-right">
        <p class="text-xs text-slate-400 uppercase tracking-wide font-semibold mb-1">Valor Total Mensal</p>
        <p class="text-2xl font-bold text-red-600" id="total_display">R$ 0,00</p>
      </div>
    </div>
  </div>

  <button type="submit" onclick="prepareSubmit(event)" class="w-full bg-red-600 text-white py-4 rounded-2xl font-bold text-base shadow-lg hover:bg-red-700 transition-all flex items-center justify-center gap-2">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
    Gerar Contrato Completo (PDF)
  </button>
</form>
<?php endif; ?>

</div>

<script>
const PLANS = <?php echo json_encode($voga_plans); ?>;
function fmt(v){ return 'R$ '+parseFloat(v).toFixed(2).replace('.',','); }

function filterPlans(){
    const op = document.getElementById('operator_select').value;
    document.querySelectorAll('.plan-select').forEach(sel=>{
        const cur = sel.value;
        sel.innerHTML = '';
        PLANS.filter(p=>p.network===op).forEach(p=>{
            const o=document.createElement('option');
            o.value=p.id; o.dataset.price=p.price; o.dataset.network=p.network;
            o.textContent=p.provider+' – R$ '+p.price.toFixed(2).replace('.',',');
            sel.appendChild(o);
        });
        if(sel.querySelector('option[value="'+cur+'"]')) sel.value=cur;
    });
    updateTotal();
}

function updateTotal(){
    let total=0;
    document.querySelectorAll('#lines_table tr').forEach(row=>{
        if(row.style.display==='none') return;
        const sel=row.querySelector('.plan-select'); if(!sel) return;
        const price=parseFloat(sel.options[sel.selectedIndex]?.dataset.price||0);
        const el=row.querySelector('[id^="price_"]'); if(el) el.textContent=fmt(price);
        total+=price;
    });
    document.querySelectorAll('.new-line-select').forEach(sel=>{
        const price=parseFloat(sel.options[sel.selectedIndex]?.dataset.price||0);
        const el=sel.closest('.new-line-row')?.querySelector('.new-line-price'); if(el) el.textContent=fmt(price);
        total+=price;
    });
    document.getElementById('total_display').textContent=fmt(total);
    updateCount();
}

function cancelLine(idx){
    const row=document.getElementById('row_'+idx);
    const btn=document.getElementById('cancel_btn_'+idx);
    const inp=document.getElementById('cancel_input_'+idx);
    if(row.style.display==='none'){
        row.style.display=''; btn.textContent='Cancelar linha'; btn.classList.replace('bg-slate-100',''); inp.disabled=true;
    } else {
        row.style.display='none'; inp.disabled=false; inp.value='1'; btn.textContent='Restaurar linha';
    }
    updateTotal();
}

let nlId=0;
function addNewLine(){
    const op=document.getElementById('operator_select').value;
    const opts=PLANS.filter(p=>p.network===op).map(p=>`<option value="${p.id}" data-price="${p.price}">${p.provider} – R$ ${p.price.toFixed(2).replace('.',',')}</option>`).join('');
    const id=nlId++;
    const d=document.createElement('div');
    d.className='new-line-row flex flex-wrap items-center gap-2 bg-slate-50 rounded-lg p-2 border border-slate-200'; d.id='nl_'+id;
    d.innerHTML=`<input type="text" placeholder="Número (ex: 11-99999-9999)" class="new-line-number border border-slate-300 rounded-lg px-2 py-1.5 text-xs w-44 outline-none focus:ring-2 focus:ring-red-400" oninput="updateTotal()"><select class="new-line-select border border-slate-200 rounded-lg px-2 py-1.5 text-xs flex-1 outline-none focus:ring-2 focus:ring-red-400" onchange="updateTotal()">${opts}</select><span class="new-line-price text-xs font-bold text-red-600 w-20 text-right">R$ 0,00</span><button type="button" onclick="document.getElementById('nl_${id}').remove();updateTotal()" class="text-red-400 hover:text-red-600"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg></button>`;
    document.getElementById('new_lines_container').appendChild(d);
    updateTotal();
}

function updateCount(){
    let c=0;
    document.querySelectorAll('#lines_table tr').forEach(r=>{ if(r.style.display!=='none') c++; });
    c+=document.querySelectorAll('.new-line-row').length;
    const el=document.getElementById('lines_count');
    if(el) el.textContent='('+c+' linha'+(c!==1?'s':'')+')';
}

function prepareSubmit(e){
    const cd={
        clientName:document.getElementById('f_name')?.value||'',
        clientCNPJ:document.getElementById('f_cnpj')?.value||'',
        clientAddress:document.getElementById('f_address')?.value||'',
        clientNeighborhood:document.getElementById('f_neighborhood')?.value||'',
        clientCity:document.getElementById('f_city')?.value||'',
        clientState:document.getElementById('f_state')?.value||'',
        clientCEP:document.getElementById('f_cep')?.value||'',
        clientPhone:document.getElementById('f_phone')?.value||'',
        clientEmail:document.getElementById('f_email')?.value||'',
        lines:<?php echo json_encode(array_values($extracted_data['lines'] ?? [])); ?>
    };
    document.getElementById('client_data_field').value=JSON.stringify(cd);
    const nl=[];
    document.querySelectorAll('.new-line-row').forEach(row=>{
        const num=row.querySelector('.new-line-number')?.value.trim();
        const sel=row.querySelector('.new-line-select');
        if(num&&sel) nl.push({number:num,plan_id:parseInt(sel.value)});
    });
    document.getElementById('new_lines_field').value=JSON.stringify(nl);
}

document.addEventListener('DOMContentLoaded',()=>{ filterPlans(); });
</script>
</body>
</html>
